package com.mainclasses;

import com.inherit.Marks;

public class StudentDetails {

	public static void main(String[] args) {

		Marks m1 = new Marks();
		m1.accept1();
		m1.accept();
		m1.display();
		m1.total();

	}
}
