package com.mainclasses;

import com.inherit.Dog;

public class MainClass {

	
	public static void main(String[] args) {

		Dog d = new Dog();
		d.dogHabitat("Human homes and yards", "Brown, Black, White");
		d.types("1.Golden Retriever 2.German Sheperd 3.BullDog");
		d.eat("Pedigree & Meat");

	}
}
