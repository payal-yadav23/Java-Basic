package com.mainclasses;

import com.inherit.Salary;

public class EmpDetails {

	public static void main(String[] args) {

		Salary s1 = new Salary();
		s1.empDetails();
		s1.accept();
		s1.empDisplay();
		s1.da();
		s1.salaryDisplay();
	}
}
