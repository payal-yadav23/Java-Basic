package com.inheritheory;

public class Theory2 extends Theory {

	public Theory2() {
		System.out.println("Theory2 constructor...!");
	}

	public static void main(String[] args) {

		Theory2 t1 = new Theory2();

	}

}