package com.inherit;

public class Animal {

	public void eat(String food) {
		System.out.println("Food that dog eat:- " + food);

	}

}
