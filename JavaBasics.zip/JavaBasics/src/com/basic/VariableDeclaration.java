package com.basic;

public class VariableDeclaration {

	public static void main(String[] args) {

		/*
		 * Syntax :-
		 * 
		 * datatype variable_name = value;
		 * 
		 */

		int a = 55; // here 'a' is variable that stores the value 55
		int b = 22; // similarly 'b' stores the value 22
		int c = a + b; // 'c' is variable that stores the logic of addition of a and b
		System.out.println("Addition :" + c);
	}
}
