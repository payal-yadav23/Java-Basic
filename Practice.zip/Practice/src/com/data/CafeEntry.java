package com.data;

import java.util.Scanner;

import com.example.Cafe;

public class CafeEntry {

	public void dataEntry() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter your Name: ");
		String name = sc.nextLine();

		System.out.println("Enter Mobile No: ");
		long mono = sc.nextLong();

		System.out.println("------MENU------");
		System.out.println("1.Hot Coffee    35rs");
		System.out.println("2.Cold Coffee   45rs");
		System.out.println("3.Hot Chocolate 60rs");
		System.out.println("4.Veg Burger    70rs");
		System.out.println();

		System.out.println("Do you want to place any order..? (Y/N)");
		char a = sc.next().charAt(0);

		if (a == 'y' || a == 'Y') {
			System.out.println("Enter how many hot coffee you want : ");
			int hcof = sc.nextInt();

			System.out.println("Enter how many cold coffee you want : ");
			int ccof = sc.nextInt();

			System.out.println("Enter how many hot chocolate you want : ");
			int choco = sc.nextInt();

			System.out.println("Enter how many veg burger you want : ");
			int burg = sc.nextInt();

			Cafe c = new Cafe(name, mono, hcof, ccof, choco, burg);

			c.display();
			System.out.println("-----------------------------------------");
			c.totalBill();
			//c.gst();
			
			System.out.println();
			System.out.println("THANK YOU FOR VISITING...!!!");

		} else {
			System.out.println("THANK YOU FOR VISITING...!!!");
		}

	}
}
