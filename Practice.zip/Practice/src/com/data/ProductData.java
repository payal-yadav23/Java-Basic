package com.data;

import java.util.Scanner;

import com.example.Product;

public class ProductData {

	public void insertData() {
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Product Id: ");
		int proid = sc.nextInt();

		System.out.println("Enter Product Name: ");
		String proname = sc.next();

		System.out.println("Enter Product Price: ");
		float price = sc.nextFloat();

		System.out.println("Enter Product Stock: ");
		int pstock = sc.nextInt();

		Product p1 = new Product(proid, proname, price, pstock);

		p1.display();

		System.out.println("Choose one from below:- ");
		System.out.println("1.PURCHASE PRODUCT");
		System.out.println("2.ADD PRODUCT");
		System.out.println("3.DISPLAY PRODUCT DETAILS");

		int num = sc.nextInt();
		switch (num) {

		case 1:
			System.out.println("Enter No of product want to purchase-");
			int purchase = sc.nextInt();
			p1.purchaseProduct(purchase);
			break;

		case 2:
			System.out.println("Enter No of product want to add in stock-");
			int add = sc.nextInt();
			p1.addStock(add);
			break;

		case 3:
			p1.display();

		default:
			System.out.println("Thank you..!!");
		}
	}
}
