package com.data;

import java.util.Scanner;

import com.example.Operators;

public class OperatorData {

	public void data() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter number1 : ");
		int n1 = sc.nextInt();

		System.out.println("Enter number2 : ");
		int n2 = sc.nextInt();

		Operators op = new Operators(n1, n2);
		op.display();

		System.out.println("-------------------------------------------------------");
		System.out.println("Choose any one operation you want:");
		System.out.println("1.ADDITION");
		System.out.println("2.SUBTRACTION ");
		System.out.println("3.MULTIPLICATION");
		System.out.println("4.DIVISION");
		System.out.println("5.MODULUS");
		System.out.println("6.EXIT(None of these)");

		int i = sc.nextInt();

		switch (i) {
		case 1:
			System.out.println("----------------------------------------------------");
			op.myAdd();
			break;
		case 2:
			System.out.println("----------------------------------------------------");

			op.mySub();
			break;
		case 3:
			System.out.println("----------------------------------------------------");
			op.myMult();
			break;
		case 4:
			System.out.println("----------------------------------------------------");
			op.myDiv();
			break;
		case 5:
			System.out.println("----------------------------------------------------");
			op.myMod();
		case 6:
			System.out.println("----------------------------------------------------");
			op.display();
			break;
		default:
			System.out.println("Pls enter Valid data...!");
		}

	}
}
