package com.data;

public class Book {

	int bookId;
	String bookTitle;
	String author;
	float price;
	int availableCopies;

	public Book(int bookId, String bookTitle, String author, float price, int availableCopies) {

		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.author = author;
		this.price = price;
		this.availableCopies = availableCopies;

	}

	public void issuedBook(int bookIssue) {

		if (availableCopies >= bookIssue) {
			System.out.println("Number of books issued are: " + bookIssue);
			availableCopies -= bookIssue;
			System.out.println("Number of books available after issued: " + availableCopies);
		} else {
			System.out.println("No books issued ");
		}
		System.out.println("------------------------------------------------------");

	}

	public void returnBook(int bookReturn) {

		System.out.println("Number of Books returned are:" + bookReturn);
		availableCopies += bookReturn;
		System.out.println("Total books avialable after return: " + availableCopies);
		System.out.println("------------------------------------------------------");

	}

	public void displayDetails() {
		System.out.println("------------BOOK DETAILS---------------");
		System.out.println("Book ID: " + bookId);
		System.out.println("Book Title: " + bookTitle);
		System.out.println("Book Author: " + author);
		System.out.println("Book price: " + price);
		System.out.println("Avialable copies of book: " + availableCopies);
		System.out.println("------------------------------------------------------");
	}

}
