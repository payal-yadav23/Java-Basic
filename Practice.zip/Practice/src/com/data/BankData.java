package com.data;

import java.util.Scanner;

import com.example.Bank;

public class BankData {

	public void data() {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Account Number:");
		int accNo = sc.nextInt();

		System.out.println("Enter Account Holder Name: ");
		String accName = sc.next();

		System.out.println("Enter Initial Balance: ");
		int bal = sc.nextInt();

		Bank b1 = new Bank(accNo, accName, bal);
		b1.display();

		System.out.println("----------------------------------------------------------------");
		System.out.println("CHOOSE AMONG THIS - ");
		System.out.println("1.DEPOSITE CASH ..!");
		System.out.println("2.WITHDRAWAL CASH..!");
		System.out.println("3.DISPLAY CURRENT BALANCE..!");
		System.out.println("4.EXIT---");
		System.out.println("----------------------------------------------------------------");

		int choose = sc.nextInt();
		switch (choose) {

		case 1:
			System.out.println("Enter amount you want to deposite: ");
			int addAmt = sc.nextInt();
			b1.depositeBal(addAmt);
			break;
		case 2:
			System.out.println("Enter amount you want to withdraw: ");
			int takeAmt = sc.nextInt();
			b1.withdrawCash(takeAmt);
			break;
		case 3:
			System.out.println("Balance in your account: ");
			b1.display();
			break;
		case 4:
			System.out.println("THANK YOU FOR VISITING--!!!!!!!!");
		}
	}
}
