package com.detail;

import com.data.CafeEntry;

public class CafeBill {

	public static void main(String[] args) {
		CafeEntry ce = new CafeEntry();
		ce.dataEntry();

	}
}
