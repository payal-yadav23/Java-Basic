package com.detail;

import com.data.BankData;

public class BankDetails {

	public static void main(String[] args) {

		BankData b2 = new BankData();
		b2.data();

		System.out.println();
		System.out.println("THANK YOU FOR VISITING--!!!!!!!!");
	}
}
