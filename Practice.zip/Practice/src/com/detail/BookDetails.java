package com.detail;

import com.data.Book;

public class BookDetails {

	public static void main(String[] args) {

		Book b1 = new Book(1234, "It ends with us", "Collen Hover", 299, 1500);

		b1.displayDetails();
		b1.issuedBook(800);
		b1.returnBook(550);
	}
}
