package com.detail;

import java.util.Scanner;

import com.example.Student;

public class StudentDeatils {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter student rollno: ");
		int rollno = sc.nextInt();
		sc.nextLine();                  //as nextInt(),nextdouble() and all doesnot consume nextline so use next() or nextLine

		System.out.println("Enter Student Name: ");
		String name = sc.nextLine();

		System.out.println("Enter Student Branch: ");
		String branch = sc.nextLine();

		System.out.println("Enter Passing year: ");
		int year = sc.nextInt();

		System.out.println("Enter total marks you got: ");
		int mark = sc.nextInt();

		Student stu = new Student(rollno, name, branch, year, mark);
		stu.display();
		int per = stu.calPercentage();
		stu.grade(per);

		System.out.println("-----------------------------------------------------------------------");

	}
}
