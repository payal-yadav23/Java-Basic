package com.detail;

import com.data.ProductData;

public class ProductDetails {

	public static void main(String[] args) {

		ProductData po = new ProductData();
		po.insertData();

		System.out.println("----------THANK YOU-------------");
	}
}
