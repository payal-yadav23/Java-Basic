package com.detail;

import com.data.OperatorData;

public class OperatorDetails {

	public static void main(String[] args) {
		
		OperatorData op1 = new OperatorData();
		op1.data();
	}
}
