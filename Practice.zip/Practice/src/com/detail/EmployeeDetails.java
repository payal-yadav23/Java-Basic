package com.detail;

import com.example.Employee;

public class EmployeeDetails {

	public static void main(String[] args) {
		Employee e1 = new Employee(101, "abc", "Software engineer", 80000);
		e1.display();
		e1.calBonus();
	}
}
