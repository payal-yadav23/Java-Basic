package com.example;

public class Operators {

	int num1;
	int num2;

	public Operators(int num1, int num2) {
		this.num1 = num1;
		this.num2 = num2;
	}

	public void myAdd() {
		System.out.println("Addition of two numbers: " + (num1 + num2));
	}

	public void mySub() {
		if (num1 < num2) {
			System.out.println("Subtraction of two numbers: " + (num2 - num1));
		} else {
			System.out.println("Substraction is negative as num2 is small than num1: " + (num2 - num1));
		}
	}

	public void myMult() {
		System.out.println("Multiplication of two numbers: " + (num1 * num2));
	}

	public void myDiv() {
		System.out.println("Division of two numbers: " + (num1 / num2));
	}

	public void myMod() {
		System.out.println("Modulus of two numbers: " + (num1 % num2));
	}

	public void display() {
		
		System.out.println("Number 1 : " + num1);
		System.out.println("Number 2 : " + num2);
	}
}
