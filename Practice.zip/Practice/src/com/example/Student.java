package com.example;

public class Student {

	int rollNo;
	String stuName;
	String course;
	int year;
	int marks;

	public Student(int rollNo, String stuName, String course, int year, int marks) {

		this.rollNo = rollNo;
		this.stuName = stuName;
		this.course = course;
		this.year = year;
		this.marks = marks;
	}

	public void display() {

		System.out.println("----------------STUDENT DETAILS ARE AS FOLLOWS-------------");
		System.out.println("Roll no: " + rollNo);
		System.out.println("Student Name: " + stuName);
		System.out.println("Course: " + course);
		System.out.println("Passing Year: " + year);
		System.out.println("Total Marks: " + marks);

	}

	public int calPercentage() {

		int percentage = marks * 100 / 500;
		System.out.println("Percentage :" + percentage + "%");
		return percentage;
	}

	public void grade(int percentage) {

		int range =  percentage / 10;

		switch (range) {
		case 9:

			System.out.println("Grade: A - Excellent");
			break;
		case 8:

			System.out.println("Grade: B - Very Good");
			break;
		case 7:

			System.out.println("Grade: C - Good");
			break;
		case 6:
			if (range > 6)
				System.out.println("Grade: D - Average");
			break;
		case 5:
			if (range < 5)
				System.out.println("Fail - Needs More Practice");
			break;
		}
	}
}
