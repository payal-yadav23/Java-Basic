package com.example;

public class Employee {

	int empId;
	String empName;
	String designation;
	double salary;

	public Employee(int empId, String empName, String designation, double salary) {

		this.empId = empId;
		this.empName = empName;
		this.designation = designation;
		this.salary = salary;

	}

	/*
	 * if we make method static then variables should also be static and in
	 * constructor we have to assign value to them through classname
	 * eg.Employee.empId=empId;
	 */

	public void display() {
		System.out.println("-----------------------EMPLOYEE DETAILS--------------------------------");
		System.out.println("Employee Id: " + empId);
		System.out.println("Employee Name: " + empName);
		System.out.println("Emmployee Designation: " + designation);
		System.out.println("Employee Salary: " + salary);
	}

	public void calBonus() {
		double bonus = 0;

		if (salary < 50000) {
			bonus = salary * 10 / 100;
			System.out.println("Bonus will be given: " + bonus);
			salary += bonus;
			System.out.println("Total salary becomes: " + salary);

		} else {
			bonus = salary * 5 / 100;
			System.out.println("Bonus will be given: " + bonus);
			salary += bonus;
			System.out.println("Total salary becomes: " + salary);
		}

		System.out.println("------------------------HAPPY DIWALI---------------------------");
	}
}
