package com.example;


public class Bank {

	int accountNo;
	String accountHolder;
	int balance;

	public Bank(int accoutNo, String accountHolder, int balance) {

		this.accountNo = accoutNo;
		this.accountHolder = accountHolder;
		this.balance = balance;

		System.out.println("----------------------------Account Details-----------------------");
	}

	public void depositeBal(int addAmount) {
		System.out.println("-------------------------------------------------");
		balance = balance + addAmount;
		System.out.println("Balance after Deposite :" + balance);
	}

	public void withdrawCash(int takeAmount) {

		System.out.println("-----------------------------------------------");
		if (takeAmount <= balance) {
			balance = balance - takeAmount;
			System.out.println("Balance after Withdraw :" + balance);
		}

		else {
			System.out.println("--TRANSACTIONS MORE THAN BALANCE NOT ALLOWED--");
		}
	}

	public void display() {
		System.out.println("Account No: " + this.accountNo);
		System.out.println("Account Holder Name : " + this.accountHolder);
		System.out.println("Balance : " + this.balance);

	}
}
