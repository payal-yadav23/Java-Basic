package com.example;

public class Cafe {

	String custName;
	long mobNo;
	int hotCoffee;
	int coldCoffee;
	int hotChoco;
	int burger;
	int n, a, b, c, d;

	public Cafe(String custName, long mobNo, int hotCoffee, int coldCoffee, int hotChoco, int burger) {

		this.custName = custName;
		this.mobNo = mobNo;
		this.hotCoffee = hotCoffee;
		this.coldCoffee = coldCoffee;
		this.hotChoco = hotChoco;
		this.burger = burger;
	}

	public String hotCof() {
		n = 35;
		a = n * hotCoffee;
		return "Hot Coffee : " + hotCoffee + "*" + n + " = " + a + "rs";
	}

	public String coldCof() {
		n = 45;
		b = n * coldCoffee;
		return "Cold Coffee : " + coldCoffee + "*" + n + " = " + b + "rs";
	}

	public String hotChocolate() {
		n = 60;
		c = n * hotChoco;
		return "Hot Chocolate : " + hotChoco + "*" + n + " = " + c + "rs";
	}

	public String burGer() {
		n = 70;
		d = n * burger;
		return "Burger : " + burger + "*" + n + " = " + d + "rs";
	}

	public void display() {
		System.out.println("--+----+----+----IRANI CAFE----+-----+----");
		System.out.println("");
		System.out.println("--------------BILL AMOUNT-----------------");
		System.out.println();
		System.out.println("Customer Name: " + custName);
		System.out.println("Mobile Number: " + mobNo);
		System.out.println();
		System.out.println("---Item---++--Price--++");
		System.out.println();
		System.out.println(hotCof());
		System.out.println(coldCof());
		System.out.println(hotChocolate());
		System.out.println(burGer());

	}

	int amt;

	public int totalBill() {
		amt = (a + b + c + d);
		System.out.println("Total Bill : " + amt + " rs");
		return amt;

	}

//	public int gst() {
//		int gstamt = 2 / 100 * amt;
//		int totalbill = gstamt + amt;
//		System.out.println("Total bill with gst 2% :" + totalbill);
//		return totalbill;
//	}
}
