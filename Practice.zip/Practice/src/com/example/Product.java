package com.example;

public class Product {

	int productId;
	String productName;
	float price;
	int stock;

	public Product(int productId, String productName, float price, int stock) {
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.stock = stock;

	}

	public void purchaseProduct(int productNo) {

		if (productNo <= stock) {
			System.out.println("Stock Purchase: " + productNo);
			stock -= productNo;
			System.out.println("Total stock Remaining: " + stock);
		} else {
			System.out.println("----No more Stock how much needed---");
		}

	}

	public void addStock(int productNo) {
		System.out.println("Stock Added: " + productNo);
		stock += productNo;
		System.out.println("Total stock when Added: " + stock);
	}

	public void display() {
		System.out.println("-----------PRODUCT STOCK DETAILS-------------");
		System.out.println("Product ID: " + productId);
		System.out.println("Product Name: " + productName);
		System.out.println("Price: " + price);
		System.out.println("Product Stock: " + stock);
		System.out.println("-----------------------------------------------");
	}
}
